﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Entities
{
    public class Candidates
    {
        public int CandidateID
        {
            get;
            set;
        }
        public string FirstName
        {
            get;
            set;
        }
        public string MiddleName
        {
            get;
            set;
        }
        public string LastName
        {
            get;
            set;
        }
        public int YearsExperience
        {
            get;
            set;
        }
        public string CVPath
        {
            get;
            set;
        }
    }
}
