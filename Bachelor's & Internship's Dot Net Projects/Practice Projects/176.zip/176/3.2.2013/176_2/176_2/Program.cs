﻿using System;


namespace _176_2
{
    class Program
    {
        static void Main(string[] args)
        {
           // #region Start of Variables
           // // Variable declaration
           //// Data Type space Name = initilization (if any)
           // int MyIntVariable;
           // string MyString ;
           // double myDouble = 50.15;
           // float test = 50.12F;

           // Int16 test16 = 15;
           // short testagain = 15;

           // // Int32 = int
           // // int64 = long

           // bool _myName = true;

           // Console.WriteLine(test16);
           // #endregion

            //#region Start of Conditions
            //int a = 10;
            //int b = 10;
            //if (a < b)
            //{
            //    Console.WriteLine("A<b");
            //}
            //else if (a == b)
            //{
            //    Console.WriteLine("Equal");
            //}
            //else
            //{
            //    Console.WriteLine("greater");
            //}
            ////==, != , < , <= , >, >= , || , && 
            //int? abc = null;
            //float? nullfloat = null;

            //#endregion

            #region Start of Switch

            //Assignment
            //switch (Statement)
            //{
            //    case 1: 
            //        // some op
            //        break;
            //    case 2:
            //        // Some op
            //        break;
            //    default: (equals to Else of If Statment))
            //        // Some op
            //        break;
            //}
            #endregion

            //#region Start of Conversion
            //// AKA Type casting
            //object o = new object();
            //int aConvert = 10;
            //float bConvert = (float)aConvert;
           
            //string result = Convert.ToString(aConvert);
            //float newTest = 158.5F;
            //int resultant = -1;
            //if (int.TryParse(newTest.ToString(), out resultant))
            //{
            //    Console.WriteLine("Conversion possible");
            //    Console.WriteLine(resultant);
            //}
            //else
            //{
            //    Console.WriteLine("Conversion not possible");
            //    Console.WriteLine(resultant);
            //}

            //#endregion
        }
    }
}
//namespace MyNameSpace
//{
//    public class Test
//    {
 
//    }
//}
