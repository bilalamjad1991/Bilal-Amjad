﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Student176;
namespace OOP
{
    class Program
    {
        static void Main(string[] args)
        {
            #region OOP
            //Student176.Student obj = new Student176.Student();
            //obj.FirstName = "ABC";
            //Console.WriteLine(obj.FirstName);

            //obj.Grade1 = "B";
            //Console.WriteLine(obj.GetPercentage());

            //Console.ReadLine();
            #endregion


            //Person p = new Person();
            //Console.WriteLine(p.Who());

            //Student s = new Student();
            //Console.WriteLine(s.Who());

            //Teacher t = new Teacher();
            //Console.WriteLine(t.Who());

            //Person p = new Teacher();
            //Console.WriteLine(p.Who());

            //Female f = new Female();
            //Console.WriteLine(f.Gender());

            //Men m = new Men();
            //Console.WriteLine(m.Gender());
            
            //Person p = new Men();
            //Console.WriteLine(p.Gender());

            Person p = new Person();
            Console.WriteLine(p.Gender());
        }
    }
}
